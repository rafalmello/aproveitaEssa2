package com.udesc.AproveitaEssaJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AproveitaEssaJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
