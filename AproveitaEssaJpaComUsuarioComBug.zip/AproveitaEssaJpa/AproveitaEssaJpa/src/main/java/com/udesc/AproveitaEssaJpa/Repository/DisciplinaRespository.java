package com.udesc.AproveitaEssaJpa.Repository;

import com.udesc.AproveitaEssaJpa.Models.Disciplina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DisciplinaRespository extends JpaRepository<Disciplina,Long> {
}
