package com.udesc.AproveitaEssaJpa.Models;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "tb_modulo")
public class Modulo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idModulo;
    private double cargaHoraria;

    private String nomeModulo;

    @JoinColumn(name = "professor_id")//indica que esse atributo é a chave estrangeira
    @ManyToOne
    private Professor professorResponsavel; //todo Modulo deve ter um professor Responsavel para tirar duvidar e dar aulas.

    @ManyToMany(mappedBy = "modulos", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List <Topico> topicos = new ArrayList<Topico>();

    @ManyToOne
    @JoinColumn(name = "disciplina_id")
    private Disciplina disciplinaCorrespondente;


    public Modulo() {//Construtor sem nada para o jpa
    }

    public Modulo(double cargaHoraria, String nomeModulo, Aluno aluno, Professor professorResponsavel,
                  List<Topico> topicos, Disciplina disciplinaCorrespondente) {

        this.cargaHoraria = cargaHoraria;
        this.nomeModulo = nomeModulo;
        this.professorResponsavel = professorResponsavel;
        this.topicos = topicos;
        this.disciplinaCorrespondente = disciplinaCorrespondente;
    }

    public Disciplina getDisciplinaCorrespondente() {
        return disciplinaCorrespondente;
    }

    public void setDisciplinaCorrespondente(Disciplina disciplinaCorrespondente) {
        this.disciplinaCorrespondente = disciplinaCorrespondente;
    }

    public double getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(double cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getNomeModulo() {
        return nomeModulo;
    }

    public void setNomeModulo(String nomeModulo) {
        this.nomeModulo = nomeModulo;
    }



    public Professor getProfessor() {
        return professorResponsavel;
    }

    public void setProfessor(Professor professor) {
        this.professorResponsavel = professor;
    }

    public List<Topico> getTopicos() {
        return topicos;
    }

    public void setTopicos(List<Topico> topicos) {
        this.topicos = topicos;
    }
}

