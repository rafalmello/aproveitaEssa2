package com.udesc.AproveitaEssaJpa.Repository;

import com.udesc.AproveitaEssaJpa.Models.Topico;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TopicoRepository extends JpaRepository<Topico,Long> {
}
