package com.udesc.AproveitaEssaJpa.Models;

import jakarta.persistence.*;

import javax.swing.text.Document;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "tb_topico")
public class Topico {

    @ManyToMany
    @JoinTable(name = "topico_modulo", joinColumns = @JoinColumn(name = "topico_id"), inverseJoinColumns = @JoinColumn(name = "modulo_id"))
    private List <Modulo> modulos = new ArrayList<Modulo>();
    private double cargaHoraria;
    private String nomeTopico;

    @Enumerated(EnumType.STRING)
    private TipoDeTopico tipoDeTopico;

    //private Document[] topicos;// = { "links","exercicio","aula","texto","prova"} ;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idTopico;

    public Topico(double cargaHoraria, String nomeTopico) {
        this.cargaHoraria = cargaHoraria;
        this.nomeTopico = nomeTopico;
    }

    public enum TipoDeTopico {
        LINKS, EXERCICIO, AULA, TEXTO
    }

    public double getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(double cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getNomeTopico() {
        return nomeTopico;
    }

    public void setNomeTopico(String nomeTopico) {
        this.nomeTopico = nomeTopico;
    }
}
