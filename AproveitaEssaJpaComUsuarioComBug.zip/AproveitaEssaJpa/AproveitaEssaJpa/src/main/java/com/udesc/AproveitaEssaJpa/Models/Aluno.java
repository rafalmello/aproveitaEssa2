package com.udesc.AproveitaEssaJpa.Models;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

import jakarta.persistence.*;
import jakarta.persistence.Table;

import java.util.ArrayList;
import java.util.List;

@Entity
@DiscriminatorValue("ALUNO")
public class Aluno  {





    private String curso;

    @OneToMany(mappedBy = "aluno", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List <Disciplina> disciplinas = new ArrayList<Disciplina>();
    @OneToMany(mappedBy = "aluno", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List <Modulo> modulos = new ArrayList<Modulo>();


    @ManyToMany
    @JoinTable(name = "aluno_professor", joinColumns = @JoinColumn(name = "aluno_id"), inverseJoinColumns = @JoinColumn(name = "professor_id"))
    private List<Professor>professores = new ArrayList<Professor>();
    private String instituicao;


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idAluno;



    public Aluno(String nome, String email, String senha, double telefone, String cpf,  String curso, List<Disciplina> disciplinas,List<Modulo> modulos) {

        this.curso = curso;

        if (this.modulos == null){
            this.modulos = new ArrayList<Modulo>();
        }
        if(this.disciplinas == null){
            this.disciplinas = new ArrayList<Disciplina>();
        }

    }

    public Aluno(){

    }

    public List<Disciplina> getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(List<Disciplina> disciplinas) {
        this.disciplinas = disciplinas;
    }

    public List<Modulo> getModulos() {

        return modulos;
    }

    public void setModulos(List<Modulo> modulos) {
        this.modulos = modulos;
    }


}
