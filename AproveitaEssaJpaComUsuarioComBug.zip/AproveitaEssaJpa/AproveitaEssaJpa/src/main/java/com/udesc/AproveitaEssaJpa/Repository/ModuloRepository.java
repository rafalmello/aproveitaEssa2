package com.udesc.AproveitaEssaJpa.Repository;


import com.udesc.AproveitaEssaJpa.Models.Modulo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ModuloRepository  extends JpaRepository<Modulo,Long> {
}
