package com.udesc.AproveitaEssaJpa.Models;

import jakarta.persistence.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "tb_disciplina")
public class Disciplina {

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinColumn(name = "idAluno")
    private List<Aluno> alunos = new ArrayList<Aluno>();


    private DateFormat dataDisciplina = new SimpleDateFormat("dd/MM/yy");


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idDisciplina;
    private String nomeDisciplina;

    private String ementa;

    private String instituicao;//pode ser retirada

    private List<String> conteudos;

    public Disciplina() {
    }

    public Disciplina(String nomeDisciplina, String instituicao, List<String> conteudos) {
        this.nomeDisciplina = nomeDisciplina;
        this.instituicao = instituicao;
        this.conteudos = conteudos;
        ;
    }

    public String getNomeDisciplina() {
        return nomeDisciplina;
    }

    public void setNomeDisciplina(String nomeDisciplina) {
        this.nomeDisciplina = nomeDisciplina;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public List<String> getConteudos() {
        return conteudos;
    }

    public void setConteudos(List<String> conteudos) {
        this.conteudos = conteudos;
    }
}

