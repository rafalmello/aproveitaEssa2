package com.udesc.AproveitaEssaJpa.Repository;public interface UsuarioRepository {
}
