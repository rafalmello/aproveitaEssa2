package com.udesc.AproveitaEssaJpa.Models;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity

public class Professor {

    protected String nome;
    protected String cpf;
    protected String email;
    protected String senha;


    protected double telefone;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idProfessor;
    private double salario;

    @ManyToMany(mappedBy = "professores")
    private List <Aluno> alunos = new ArrayList<Aluno>();


    // com o modulo o professor acessa o topico então não precisa de topico em professor
    @OneToMany(mappedBy = "professorResponsavel", cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private List <Modulo> modulosProfessor = new ArrayList<Modulo>();

    //private List<Topico>topicos;


    public Professor(String nome, String email, String senha, double telefone, double salario,
                     List<Aluno> alunos, List<Modulo> modulosProfessor, String cpf) {


        this.salario = salario;
        this.alunos = alunos;
        this.modulosProfessor = modulosProfessor;
    }

    public Professor(){

    }








    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }



    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<Aluno> alunos) {
        this.alunos = alunos;
    }

    public List<Modulo> getModulosProfessor() {
        return modulosProfessor;
    }

    public void setModulosProfessor(List<Modulo> modulosProfessor) {
        this.modulosProfessor = modulosProfessor;
    }
}
