package com.udesc.AproveitaEssaJpa.Repository;

import com.udesc.AproveitaEssaJpa.Models.Professor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfessorRepository extends JpaRepository<Professor,Long> {
}
