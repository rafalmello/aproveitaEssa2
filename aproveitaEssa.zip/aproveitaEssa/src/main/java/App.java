import view.TelaCadastroAluno;
import view.TelaLogin;
import view.TelaPrincipalAluno;
import view.TelaPrincipalProfessor;

public class App {
    public static void main(String[] args) {

        abrirTodasTelas();
        //TelaLogin telaLogin = new TelaLogin();

       // TelaCadastroAluno telaCadastroAluno= new TelaCadastroAluno();
        TelaPrincipalProfessor telaPrincipalProfessor = new TelaPrincipalProfessor();

        //TelaPrincipalAluno telaPrincipalAluno = new TelaPrincipalAluno();
        System.out.println("Hello world!");
    }

    public static void abrirTodasTelas(){
        TelaLogin telaLoginn = new TelaLogin();

        TelaCadastroAluno telaCadastroAluno= new TelaCadastroAluno();
        TelaPrincipalProfessor telaPrincipalProfessor = new TelaPrincipalProfessor();

        TelaPrincipalAluno telaPrincipalAluno = new TelaPrincipalAluno();
    }
}