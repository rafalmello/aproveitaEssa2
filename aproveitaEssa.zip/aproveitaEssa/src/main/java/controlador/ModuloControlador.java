package controlador;

import Models.Disciplina;
import Models.Modulo;
import Models.Topico;
import bancoDeDados_dao.TopicosDao;

import java.util.List;

public class ModuloControlador {

    private Modulo modulo;
    private Disciplina disciplina;
    TopicosDao daoTopicos;


    public ModuloControlador(Modulo modulo) {
        this.modulo = modulo;
    }

//recebe um modulo vazio e retorna um modulo montado>>> botão montar modulo.
    public Modulo MontarModulo(List <Topico> topicosDisponiveis, List <String> conteudosDaDisciplina, Modulo modulo){

        List <String> assuntosDaDisciplina1 = conteudosDaDisciplina;
        String conteudo = null;
        boolean temTodosConteudos;


        try {
            //"pegar" todos os conteudos da disciplina
            for (String  Conteudo :   conteudosDaDisciplina) {
                conteudo = Conteudo;

                temTodosConteudos = false;// ainda não tem o conteudo
                //"pegar" todos os topicos do sistema e ver se tem algum topico com o mesmo nome do conteudo da disciplina
                for (Topico topico : daoTopicos.getTopicos()){
                    //adicionar os topicos que tem assuntos equivalentes.
                    if (topico.getNomeTopico() == conteudo){
                        modulo.getTopicos().add(topico);
                        temTodosConteudos = true; // recebe true pq o conteudo foi encontrado
                    }


                }
                if (temTodosConteudos){
                    System.out.println("O conteúdo: " + conteudo + " não tem um topico equivalente");
                }

            }

        }catch (Exception exception){
            System.out.println("O conteúdo: " + conteudo + " não tem um topico equivalente");
        }





        return modulo;
    }


}
