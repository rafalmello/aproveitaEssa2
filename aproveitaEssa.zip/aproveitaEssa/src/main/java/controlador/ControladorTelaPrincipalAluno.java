package controlador;

import view.TelaPrincipalAluno;

public class ControladorTelaPrincipalAluno {
    TelaPrincipalAluno telaPrincipalAluno = new TelaPrincipalAluno();



}
