package view;

import javax.swing.*;

public class telaModulosProfessor {

    private  JLabel jlMostrarModulos;
    public telaModulosProfessor() {

    }
}
