package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;


public class TelaPrincipalProfessor extends JFrame implements JanelaUsabilidade {

    private JButton btnAcessarModulos;

    private JButton btnVerMeusALunos;

    private JButton btnSugerirTopicoNovo;

    private JButton jbVoltar;

    public TelaPrincipalProfessor()  {
        setTitle("Tela principal do Professor");
        setVisible(true);
        setSize(900,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);

        btnAcessarModulos = new JButton("Acessar Modulos");
        btnAcessarModulos.setBounds(550,450,250,70);
        btnAcessarModulos.setFont(new Font("Arial", Font.ITALIC,15));
        btnAcessarModulos.setForeground(new Color(23, 11, 217));
        btnAcessarModulos.setBackground(new Color(2, 1, 1));
        add(btnAcessarModulos);
        btnAcessarModulos.addActionListener(this :: irTelaModulos);

        btnVerMeusALunos  = new JButton("Ver Alunos");
        btnVerMeusALunos.setBounds(550,250,250,70);
        btnVerMeusALunos.setFont(new Font("Arial", Font.ITALIC,15));
        btnVerMeusALunos.setForeground(new Color(23, 11, 217));
        btnVerMeusALunos.setBackground(new Color(2, 1, 1));
        add(btnVerMeusALunos);

        btnSugerirTopicoNovo = new JButton("Sugerir Tópico");
        btnSugerirTopicoNovo.setBounds(200,250,250,70);
        btnSugerirTopicoNovo.setFont(new Font("Arial", Font.ITALIC,15));
        btnSugerirTopicoNovo.setForeground(new Color(6, 9, 190));
        btnSugerirTopicoNovo.setBackground(new Color(2, 1, 1));
        add(btnSugerirTopicoNovo);

        jbVoltar = new JButton("voltar");
        jbVoltar.setBounds(10,10,100,30);
        jbVoltar.setFont(new Font("Arial", Font.ITALIC,15));
        jbVoltar.setForeground(new Color(6, 9, 190));
        jbVoltar.setBackground(new Color(2, 1, 1));
        add(jbVoltar);
        jbVoltar.addActionListener(this:: voltar);

    }

    private void voltar(ActionEvent actionEvent) {
    }

    private void irTelaModulos(ActionEvent actionEvent) {
        telaModulosProfessor telaModulosProfessor = new telaModulosProfessor();
    }


    @Override
    public void STATICgetInstance() {

    }

    @Override
    public void STATICfecharJanela() {

    }

    @Override
    public boolean STATICisJanelaAberta() {
        return false;
    }

    @Override
    public void STATICverificaJanelaAberta() {

    }
}
