package view;

public interface JanelaUsabilidade {


    void  STATICgetInstance();

    // Método para fechar a janela
    void STATICfecharJanela();

    // Método para verificar se a janela está aberta
     boolean STATICisJanelaAberta();

    void STATICverificaJanelaAberta();
        // Verifica se a janela já está aberta antes de criar uma nova instância
       /* if (!MinhaJanela.isJanelaAberta()) {
            // Obtenha a instância da janela
            MinhaJanela janela = MinhaJanela.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }*/

}

