package view;

import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class PDFFileReceiver extends JFrame {
    private JTextField filePathField;
    private JButton browseButton;

    public PDFFileReceiver() {
        setTitle("PDF File Receiver");
        setSize(800, 550);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        filePathField = new JTextField(20);
        filePathField.setEditable(false);

        browseButton = new JButton("Browse");
        browseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                JFileChooser fileChooser = new JFileChooser();

                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

                int option = fileChooser.showOpenDialog(PDFFileReceiver.this);

                if (option == JFileChooser.APPROVE_OPTION) {
                    File file = fileChooser.getSelectedFile();
                    String filePath = file.getAbsolutePath();
                    if (filePath.toLowerCase().endsWith(".pdf")) {
                        filePathField.setText(filePath);
                    } else {
                        JOptionPane.showMessageDialog(PDFFileReceiver.this, "Por favor, selecione um arquivo PDF.");
                    }
                }
            }

        });

        JPanel panel = new JPanel();
        panel.add(filePathField);
        panel.add(browseButton);

        getContentPane().add(panel);
    }

   /* public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new PDFFileReceiver().setVisible(true);
            }
        });
    }*/
}

