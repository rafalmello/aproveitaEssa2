package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TelaPrincipalAluno extends JFrame implements JanelaUsabilidade {

    private static TelaPrincipalAluno instancia = null;
    // Variável para controlar o estado da janela
    private static boolean janelaAberta = false;

    private JButton jbVoltar;

    private JButton btnTrazerMateria;
    private JButton btnverMateriasButton;
    private JButton btnAcessarModulos;
    private JButton btnSugerirTopicoNovo;

    public TelaPrincipalAluno() {
        setTitle("Tela principal do aluno");
        setVisible(true);
        setSize(900,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);

        jbVoltar = new JButton("voltar");
        jbVoltar.setBounds(10,10,100,30);
        jbVoltar.setFont(new Font("Arial", Font.ITALIC,15));
        jbVoltar.setForeground(new Color(6, 9, 190));
        jbVoltar.setBackground(new Color(2, 1, 1));
        add(jbVoltar);
        jbVoltar.addActionListener(this:: voltar);

        btnTrazerMateria  = new JButton("trazer matéria nova");
        btnTrazerMateria.setBounds(50,150,250,70);
        btnTrazerMateria.setFont(new Font("Arial", Font.ITALIC,15));
        btnTrazerMateria.setForeground(new Color(6, 9, 190));
        btnTrazerMateria.setBackground(new Color(2, 1, 1));
        add(btnTrazerMateria);

        btnverMateriasButton  = new JButton("ver matérias que eu já trouxe");
        btnverMateriasButton.setBounds(50,250,250,70);
        btnverMateriasButton.setFont(new Font("Arial", Font.ITALIC,15));
        btnverMateriasButton.setForeground(new Color(6, 9, 190));
        btnverMateriasButton.setBackground(new Color(2, 1, 1));
        add(btnverMateriasButton);



        btnAcessarModulos  = new JButton("acessar meus módulos");
        btnAcessarModulos.setBounds(400,150,250,70);
        btnAcessarModulos.setFont(new Font("Arial", Font.ITALIC,15));
        btnAcessarModulos.setForeground(new Color(6, 9, 190));
        btnAcessarModulos.setBackground(new Color(2, 1, 1));
        add(btnAcessarModulos);
        btnAcessarModulos.addActionListener(this:: irParaTelaModulos);



        btnSugerirTopicoNovo = new JButton("Sugerir Tópico");
        btnSugerirTopicoNovo.setBounds(400,250,250,70);
        btnSugerirTopicoNovo.setFont(new Font("Arial", Font.ITALIC,15));
        btnSugerirTopicoNovo.setForeground(new Color(6, 9, 190));
        btnSugerirTopicoNovo.setBackground(new Color(2, 1, 1));
        add(btnSugerirTopicoNovo);

        super.repaint();// para fazer o refresh de tela da parte gráfica
    }

    private void voltar(ActionEvent actionEvent) {
        this.toBack();
        TelaLogin.getInstance();
    }

    private void irParaTelaModulos(ActionEvent actionEvent) {
        TelaModulosAluno.getInstance();
        TelaModulosAluno.getInstance().toFront();

    }


    @Override
    public void STATICgetInstance() {
        getInstance();
    }
    public static TelaPrincipalAluno getInstance() {
        if (instancia == null) {
            instancia = new TelaPrincipalAluno();
            // Define o estado da janela como aberta
            janelaAberta = true;
        }
        return instancia;
    }

    @Override
    public void STATICfecharJanela() {
        fecharJanela();
        dispose();
    }

    public static void fecharJanela() {
        // Define o estado da janela como fechada
        janelaAberta = false;
    }


    @Override
    public boolean STATICisJanelaAberta() {
        return isJanelaAberta();
    }

    public static boolean isJanelaAberta() {
        return janelaAberta;
    }

    @Override
    public void STATICverificaJanelaAberta() {
        verificaJanelaAberta();
    }
    public static void verificaJanelaAberta(){
        if (!TelaPrincipalAluno.isJanelaAberta()) {
            // Obtenha a instância da janela
            TelaPrincipalAluno janela = TelaPrincipalAluno.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }

    }
}

