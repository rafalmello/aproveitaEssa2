package view;

import java.io.File;
import java.io.IOException;

import java.util.*;

//import org.apache.pdfbox.pdmodel.PDDocument;
//import org.apache.pdfbox.text.PDFTextStripper;

import javax.swing.text.Document;

public class PDFReader {

    public static String readPDF(String filePath) {
        File file = new File(filePath);
        /*try {
          // Document document = Document.load(file);
          // PDFTextStripper pdfStripper = new PDFTextStripper();
           //String content = pdfStripper.getText(document);
          // document.close();
            //return content;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }*/
        return  null;
    }

    public static void main(String[] args) {
        // Testando a leitura de um arquivo PDF
        String filePath = "caminho/do/seu/arquivo.pdf"; // Insira o caminho do seu arquivo PDF aqui
        String content = readPDF(filePath);
        if (content != null) {
            System.out.println("Conteúdo do PDF:");
            System.out.println(content);
        } else {
            System.out.println("Erro ao ler o arquivo PDF.");
        }
    }
}
