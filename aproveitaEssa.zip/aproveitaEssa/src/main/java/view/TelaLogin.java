package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;


public class TelaLogin extends JFrame implements JanelaUsabilidade {

    // Variável estática para manter a referência à instância da janela
    private static TelaLogin instancia = null;
    // Variável para controlar o estado da janela
    private static boolean janelaAberta = false;

    private JLabel jlFazerLoginCPF;
    private JTextField txtFazerLoginCPF;
    private JLabel lblSenha;
    private JTextField txtSenha;
    private JButton btnEntrarAluno;
    private JButton btnEntrarProfessor;

    private JButton btnCadastrarAluno;

    private JButton btnCadastrarProfessor;


    public TelaLogin() {
        super.repaint();// para fazer o refresh de tela da parte gráfica

        setTitle("Tela Login");
        setVisible(true);
        setSize(900, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);// para fechar só a Janela
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);

        jlFazerLoginCPF = new JLabel("Insira o seu Login(CPF):");
        jlFazerLoginCPF.setBounds(50, 200, 190, 70);
        jlFazerLoginCPF.setFont(new Font("Arial", Font.ITALIC, 15));
        add(jlFazerLoginCPF);

        txtFazerLoginCPF = new JTextField();
        txtFazerLoginCPF.setBounds(280, 200, 400, 70);
        txtFazerLoginCPF.setFont(new Font("Arial", Font.ITALIC, 15));
        add(txtFazerLoginCPF);
        txtFazerLoginCPF.setVisible(true);

        lblSenha = new JLabel("Insira a sua senha:");
        lblSenha.setBounds(50, 20, 190, 70);
        lblSenha.setFont(new Font("Arial", Font.ITALIC, 15));
        add(lblSenha);

        txtSenha = new JTextField();
        txtSenha.setBounds(280, 20, 400, 70);
        txtSenha.setFont(new Font("Arial", Font.ITALIC, 15));
        add(txtSenha);
        txtSenha.setVisible(true);


        btnEntrarAluno = new JButton("fazer login como aluno");
        btnEntrarAluno.setBounds(250, 350, 350, 70);
        btnEntrarAluno.setFont(new Font("Arial", Font.BOLD, 19));
        btnEntrarAluno.setForeground(new Color(23, 11, 217));
        btnEntrarAluno.setBackground(new Color(2, 1, 1));
        add(btnEntrarAluno);
        btnEntrarAluno.addActionListener(this::compararLoginEhSenhaAluno);

        btnEntrarProfessor = new JButton("fazer login como Professor");
        btnEntrarProfessor.setBounds(250, 450, 350, 70);
        btnEntrarProfessor.setFont(new Font("Arial", Font.BOLD, 19));
        btnEntrarProfessor.setForeground(new Color(23, 11, 217));
        btnEntrarProfessor  .setBackground(new Color(2, 1, 1));
        add(btnEntrarProfessor);
        btnEntrarProfessor.addActionListener(this::compararLoginEhSenhaProfessor);

        btnCadastrarAluno = new JButton("cadastrar aluno");
        btnCadastrarAluno.setBounds(250, 520, 350, 70);
        btnCadastrarAluno.setFont(new Font("Arial", Font.BOLD, 19));
        btnCadastrarAluno.setForeground(new Color(23, 11, 217));
        btnCadastrarAluno.setBackground(new Color(2, 1, 1));
        add(btnCadastrarAluno);
        btnCadastrarAluno.addActionListener(this::cadastrarAluno);

        btnCadastrarProfessor = new JButton("cadastrar Professor");
        btnCadastrarProfessor.setBounds(250, 600, 350, 70);
        btnCadastrarProfessor.setFont(new Font("Arial", Font.BOLD, 19));
        btnCadastrarProfessor.setForeground(new Color(23, 11, 217));
        btnCadastrarProfessor.setBackground(new Color(2, 1, 1));
        add(btnCadastrarProfessor);
        btnCadastrarProfessor.addActionListener(this::cadastrarProfessor);

        super.repaint();// para fazer o refresh de tela da parte gráfica

    }

    public void cadastrarProfessor(ActionEvent actionEvent) {
        TelaCadastroProfessor.getInstance().toFront();
    }

    private void cadastrarAluno(ActionEvent actionEvent) {
        TelaCadastroAluno.getInstance().toFront();
    }

    private void compararLoginEhSenhaProfessor(ActionEvent actionEvent) {
    }

    private void compararLoginEhSenhaAluno(ActionEvent actionEvent) {

    }

    @Override
    public void STATICgetInstance() {
        getInstance();
    }
    public static TelaLogin getInstance() {
        if (instancia == null) {
            instancia = new TelaLogin();
            // Define o estado da janela como aberta
            janelaAberta = true;
        }
        return instancia;
    }

    @Override
    public void STATICfecharJanela() {
        fecharJanela();
        dispose();
    }
    public static void fecharJanela() {
        // Define o estado da janela como fechada
        janelaAberta = false;
    }

    @Override
    public boolean STATICisJanelaAberta() {
        return isJanelaAberta();
    }
    public static boolean isJanelaAberta() {
        return janelaAberta;
    }

    @Override
    public void STATICverificaJanelaAberta() {
        verificaJanelaAberta();
    }

    public static void verificaJanelaAberta(){
        if (!TelaLogin.isJanelaAberta()) {
            // Obtenha a instância da janela
            TelaLogin janela = TelaLogin.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }
    }
}
