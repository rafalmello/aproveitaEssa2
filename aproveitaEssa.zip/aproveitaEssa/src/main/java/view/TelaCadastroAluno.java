package view;

import Models.Aluno;
import bancoDeDados_dao.Conexao;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class TelaCadastroAluno extends JFrame implements JanelaUsabilidade {

    // Variável estática para manter a referência à instância da janela

    Conexao conexao = null;
    private static TelaCadastroAluno instancia = null;
    // Variável para controlar o estado da janela
    private static boolean janelaAberta = false;
    private JLabel jlNome;
    private JLabel jlEmail;

    private JLabel jlTelefone;

    private JLabel jlNomeDoCurso;

    private JLabel jlSenha;
    ///

    private JTextField getTxtNome;
    private JTextField getTxtEmail;//
    private JTextField getTxtTelefone;//

    private JTextField getTxtNomeDoCurso;//

    private JTextField getTxtSenha;

    private JButton jbVoltar;


    private JButton jbCriarAluno;


    public JTextField getGetTxtEmail() {
        return getTxtEmail;
    }

    public void setGetTxtEmail(JTextField getTxtEmail) {
        this.getTxtEmail = getTxtEmail;
    }

    public TelaCadastroAluno() {



        setTitle("Tela para Cadastrar Aluno");
        setVisible(true);
        setSize(900,800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);



        jlNome = new JLabel("Nome : ");
        jlNome.setBounds(100,100,190,140);
        jlNome.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlNome);

        jlNomeDoCurso = new JLabel("Nome do curso: ");
        jlNomeDoCurso.setBounds(100,200,190,140);
        jlNomeDoCurso.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlNomeDoCurso);

        jlEmail = new JLabel("Email: ");
        jlEmail.setBounds(100,300,90,100);
        jlEmail.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlEmail);

        jlTelefone = new JLabel("Telefone: ");
        jlTelefone.setBounds(100,400,90,100);
        jlTelefone.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlTelefone);

        jlSenha = new JLabel("Senha: ");
        jlSenha.setBounds(100,500,90,100);
        jlSenha.setFont(new Font("Arial",Font.ITALIC,15));
        add(jlSenha);


        //////////



        getTxtNome = new JTextField ();
        getTxtNome.setBounds(250,100,190,50);
        getTxtNome.setFont(new Font("Arial",Font.ITALIC,15));
        add(getTxtNome);
        getTxtNome.setVisible(true);

        getTxtNomeDoCurso = new JTextField();
        getTxtNomeDoCurso.setBounds(250,200,190,50);
        getTxtNomeDoCurso.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtNomeDoCurso);
        getTxtNomeDoCurso.setVisible(true);

        getTxtEmail = new JTextField();
        getTxtEmail.setBounds(250,300,190,50);
        getTxtEmail.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtEmail);
        getTxtEmail.setVisible(true);

        getTxtTelefone = new JTextField();
        getTxtTelefone.setBounds(250,400,190,50);
        getTxtTelefone.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtTelefone);
        getTxtTelefone.setVisible(true);

        getTxtSenha = new JTextField();
        getTxtSenha.setBounds(250,500,190,50);
        getTxtSenha.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtSenha);
        getTxtSenha.setVisible(true);



        jbVoltar = new JButton("voltar");
        jbVoltar.setBounds(10,10,100,30);
        jbVoltar.setFont(new Font("Arial", Font.ITALIC,15));
        jbVoltar.setForeground(new Color(6, 9, 190));
        jbVoltar.setBackground(new Color(2, 1, 1));
        add(jbVoltar);
        jbVoltar.addActionListener(this:: voltar);

        jbCriarAluno  = new JButton("Criar novo Aluno");
        jbCriarAluno.setBounds(550,450,350,70);
        jbCriarAluno.setFont(new Font("Arial", Font.ITALIC,20));
        jbCriarAluno.setForeground(new Color(23, 11, 217));
        jbCriarAluno.setBackground(new Color(2, 1, 1));
        add(jbCriarAluno);
       jbCriarAluno.addActionListener(this :: CriarAluno);


        super.repaint();// para fazer o refresh de tela da parte gráfica





    }

    private void CriarAluno(ActionEvent actionEvent) {


        try{

            String nome = getTxtNome.getText();
            String email = getTxtEmail.getText();
            String senha = getTxtSenha.getText();
            String curso = getTxtNomeDoCurso.getText();
            String cpf = "45252";
            Integer telefone = Integer.valueOf(getTxtTelefone.getText());


            Aluno aluno = new Aluno(nome,email,senha,telefone,cpf,314,curso,new ArrayList<>(),new ArrayList<>());


            //AlunoDao.

            JOptionPane.showMessageDialog(null,"aluno Criado com Sucesso.");
            limparTela();

        }catch (Exception e){
            JOptionPane.showInputDialog("não foi possível fazer o cadastro");
        }


      //  AlunoDao.
    }

    private void limparTela() {
        getTxtNome.setText("");
        getTxtEmail.setText("");
        getTxtSenha.setText("");
        getTxtNomeDoCurso.setText("");
        getTxtTelefone.setText("");
    }


    private void voltar(ActionEvent actionEvent) {
        TelaLogin.getInstance().toFront();
    }

    @Override
    public void STATICgetInstance() {
        getInstance();
    }

    public static TelaCadastroAluno getInstance(){
        if (instancia == null) {
            instancia = new TelaCadastroAluno();
            // Define o estado da janela como aberta
            janelaAberta = true;
        }
        return instancia;

    }

    @Override
    public void STATICfecharJanela() {
        fecharJanela();
        dispose();
    }

    private static void fecharJanela() {
        // Define o estado da janela como fechada
        janelaAberta = false;
    }


    @Override
    public boolean STATICisJanelaAberta() {
        return isJanelaAberta();
    }

    private static boolean isJanelaAberta() {
        return janelaAberta;
    }

    @Override
    public void STATICverificaJanelaAberta() {
        verificaJanelaAberta();
    }

    private static void verificaJanelaAberta() {
        if (!TelaCadastroAluno.isJanelaAberta()) {
            // Obtenha a instância da janela
            TelaCadastroAluno telaCadastroAluno = TelaCadastroAluno.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }
    }


}
