package view;

import Models.Aluno;
import Models.Modulo;
import Models.Professor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;


public class TelaCadastroProfessor extends JFrame implements JanelaUsabilidade {

    // Variável estática para manter a referência à instância da janela
    private static TelaCadastroProfessor instancia = null;
    // Variável para controlar o estado da janela
    private static boolean janelaAberta = false;

    private Professor professor;

    private JLabel jlNome;
    private JLabel jlEmail;

    private JLabel jlTelefone;

    private JLabel jlSalario;

    private JLabel jlSenha;
    ///

    private JTextField getTxtNome;
    private JTextField getTxtEmail;//
    private JTextField getTxtTelefone;//

    private JTextField getTxtSalario;//

    private JTextField getTxtSenha;

    private JButton jbVoltar;


    private JButton jbCriarProfessor;


    public JTextField getGetTxtEmail() {
        return getTxtEmail;
    }

    public void setGetTxtEmail(JTextField getTxtEmail) {
        this.getTxtEmail = getTxtEmail;
    }

    public TelaCadastroProfessor() {



        setTitle("Tela para Cadastrar Aluno");
        setVisible(true);
        setSize(900,800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);



        jlNome = new JLabel("Nome : ");
        jlNome.setBounds(100,80,190,140);
        jlNome.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlNome);

        jlSalario = new JLabel("Salário: ");
        jlSalario.setBounds(100,180,190,140);
        jlSalario.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlSalario);

        jlEmail = new JLabel("Email: ");
        jlEmail.setBounds(100,280,90,100);
        jlEmail.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlEmail);

        jlTelefone = new JLabel("Telefone: ");
        jlTelefone.setBounds(100,380,90,100);
        jlTelefone.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlTelefone);

        jlSenha = new JLabel("Senha: ");
        jlSenha.setBounds(100,480,90,100);
        jlSenha.setFont(new Font("Arial",Font.ITALIC,15));
        add(jlSenha);


        //////////



        getTxtNome = new JTextField ();
        getTxtNome.setBounds(250,100,190,50);
        getTxtNome.setFont(new Font("Arial",Font.ITALIC,15));
        add(getTxtNome);
        getTxtNome.setVisible(true);

        getTxtSalario = new JTextField();
        getTxtSalario.setBounds(250,200,190,50);
        getTxtSalario.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtSalario);
        getTxtSalario.setVisible(true);

        getTxtEmail = new JTextField();
        getTxtEmail.setBounds(250,300,190,50);
        getTxtEmail.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtEmail);
        getTxtEmail.setVisible(true);

        getTxtTelefone = new JTextField();
        getTxtTelefone.setBounds(250,400,190,50);
        getTxtTelefone.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtTelefone);
        getTxtTelefone.setVisible(true);

        getTxtSenha = new JTextField();
        getTxtSenha.setBounds(250,500,190,50);
        getTxtSenha.setFont(new Font("Arial", Font.ITALIC,15));
        add(getTxtSenha);
        getTxtSenha.setVisible(true);

        /////////////

        jbVoltar = new JButton("voltar");
        jbVoltar.setBounds(10,10,100,30);
        jbVoltar.setFont(new Font("Arial", Font.ITALIC,15));
        jbVoltar.setForeground(new Color(6, 9, 190));
        jbVoltar.setBackground(new Color(2, 1, 1));
        add(jbVoltar);
        jbVoltar.addActionListener(this:: voltar);


        jbCriarProfessor = new JButton("Criar novo Aluno");
        jbCriarProfessor.setBounds(550,450,350,70);
        jbCriarProfessor.setFont(new Font("Arial", Font.ITALIC,20));
        jbCriarProfessor.setForeground(new Color(23, 11, 217));
        jbCriarProfessor.setBackground(new Color(2, 1, 1));
        add(jbCriarProfessor);
        jbCriarProfessor.addActionListener(this :: CriarProfessor);

    }

    private void CriarProfessor(ActionEvent actionEvent) {
        String nome = getTxtNome.getText();
        String email =   getTxtEmail.getText();
        String senha = getTxtSenha.getText();
        double salario = Double.parseDouble(getTxtSalario.getText());
        Integer telefone = Integer.valueOf(getTxtTelefone.getText());

        List<Aluno>alunos = new ArrayList<Aluno>();
        List<Modulo> modulos = new ArrayList<Modulo>();

       // Professor p = new Professor(nome,email,senha,telefone,Professor.getIdProfessor2(),salario,alunos,modulos);
        //ProfessorDao.getTodosProfessores().add(p);

    }

    private void voltar(ActionEvent actionEvent) {
        TelaLogin.getInstance().toFront();
    }

    @Override
    public void STATICgetInstance() {
        getInstance();
    }

    public static TelaCadastroProfessor getInstance() {
        if (instancia == null) {
            instancia = new TelaCadastroProfessor();
            // Define o estado da janela como aberta
            janelaAberta = true;
        }
        return instancia;
    }

    @Override
    public void STATICfecharJanela() {
        fecharJanela();
        dispose();
    }

    private static void fecharJanela() {
        janelaAberta = false;
    }


    @Override
    public boolean STATICisJanelaAberta() {
        return isJanelaAberta();
    }

    public static boolean isJanelaAberta(){
        return janelaAberta;
    }

    @Override
    public void STATICverificaJanelaAberta() {
        verificaJanelaAberta();
    }

    public void verificaJanelaAberta(){
        if (!TelaCadastroProfessor.isJanelaAberta()) {
            // Obtenha a instância da janela
            TelaCadastroProfessor janela = TelaCadastroProfessor.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }

    }

}
