package view;

public class BtnVoltar {

    //Recebe 2 classes, e faz ir de uma para outra com um metodo que aceita 2 telas
    //recebe 1 calsse e faz a transição.
}
