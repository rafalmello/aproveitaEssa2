package view;

import Models.Aluno;
import Models.Disciplina;
import Models.Modulo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;



public class TelaModulosAluno extends JFrame implements JanelaUsabilidade {

    private static TelaModulosAluno instancia = null;
    // Variável para controlar o estado da janela
    private static boolean janelaAberta = false;

    Aluno aluno;

    JButton jbVoltar;

    JLabel jlConfirmarModulo;
    JComboBox opcoesDeModulos;

    JButton btnConfirmarModulo;



    public TelaModulosAluno() {
        setTitle("Módulos do aluno");
        setVisible(true);
        setSize(900,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);


        opcoesDeModulos = new JComboBox<>();
        opcoesDeModulos.setBounds(350,200,250,50);
        add(opcoesDeModulos);

        jbVoltar = new JButton("voltar");
        jbVoltar.setBounds(10,10,100,30);
        jbVoltar.setFont(new Font("Arial", Font.ITALIC,15));
        jbVoltar.setForeground(new Color(6, 9, 190));
        jbVoltar.setBackground(new Color(2, 1, 1));
        add(jbVoltar);
        jbVoltar.addActionListener(this:: voltar);


        btnConfirmarModulo = new JButton("confirmar módulo");
        btnConfirmarModulo.setBounds(650,200,250,70);
        btnConfirmarModulo.setFont(new Font("Arial", Font.ITALIC,15));
        btnConfirmarModulo.setForeground(new Color(6, 9, 190));
        btnConfirmarModulo.setBackground(new Color(2, 1, 1));
        add(btnConfirmarModulo);
        btnConfirmarModulo.addActionListener(this::confirmarEscolha);
        btnConfirmarModulo.addActionListener(this:: definirTamanhoDoJComboBox);

        jlConfirmarModulo = new JLabel("escolha qual módulo você quer: ");
        jlConfirmarModulo.setBounds(50,200,300,100);
        jlConfirmarModulo.setFont(new Font("Arial", Font.ITALIC,15));
        add(jlConfirmarModulo);

        super.repaint();
    }

    private void voltar(ActionEvent actionEvent) {
        this.toBack();
        TelaModuloEscolhido.getInstance().toFront();
        //TelaPrincipalAluno
    }

    Modulo modulo;

    private void definirTamanhoDoJComboBox(ActionEvent actionEvent) {


        List<Modulo> modulos = new ArrayList<>();
        List<Disciplina> disciplinas = new ArrayList<Disciplina>();
        Aluno aluno1 = new Aluno("Rafael",null,null,425,"44323",2, "",disciplinas ,modulos );

        for (int i =0; i<5 ; i++){
            Modulo m = new Modulo(2.0,"pin"+ i,null,null,null,null);
            aluno1.getModulos().add(m);
        }
        for (Modulo modulo: aluno1.getModulos() ){
            opcoesDeModulos.addItem(modulo.getNomeModulo());
        }

    }



    private void confirmarEscolha(ActionEvent actionEvent) {

        String moduloSelecionado = (String) opcoesDeModulos.getSelectedItem();//para pegar o nome do modulo selecionado
        TelaModuloEscolhido.getInstance();
        TelaModuloEscolhido.getInstance().toFront();


    }
    @Override
    public void STATICgetInstance() {
        getInstance();
    }
    public static TelaModulosAluno getInstance(){
        if (instancia == null) {
            instancia = new TelaModulosAluno();
            // Define o estado da janela como aberta
            janelaAberta = true;
        }
        return instancia;
    }

    @Override
    public void STATICfecharJanela() {
        fecharJanela();
        dispose();
    }

    private static void fecharJanela() {
        janelaAberta = false;
    }

    @Override
    public boolean STATICisJanelaAberta() {
        return isJanelaAberta();
    }

    private static boolean isJanelaAberta() {
        return janelaAberta;
    }

    @Override
    public void STATICverificaJanelaAberta() {
        verificaJanelaAberta();
    }

    private void verificaJanelaAberta() {
        if (TelaModulosAluno.isJanelaAberta()) {
            // Obtenha a instância da janela
            TelaModulosAluno telaModulosAluno =  TelaModulosAluno.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }
    }
}
