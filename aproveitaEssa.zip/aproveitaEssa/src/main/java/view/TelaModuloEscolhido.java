package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TelaModuloEscolhido extends JFrame implements JanelaUsabilidade {



    private static TelaModuloEscolhido instancia = null;

    private static boolean TelaAberta = false;

    private JButton jbVoltar;

    private static String nomeModulo = "";

    private static String nomeModulo2 = null;



    public TelaModuloEscolhido(String nomeModulo) {

        this.nomeModulo2 = nomeModulo;

        setTitle("Tela Modulo Escolhido");
        setVisible(true);
        setSize(900,500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//tipo de janela no fechamento
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);

        jbVoltar = new JButton("voltar");
        jbVoltar.setBounds(10,10,100,30);
        jbVoltar.setFont(new Font("Arial", Font.ITALIC,15));
        jbVoltar.setForeground(new Color(6, 9, 190));
        jbVoltar.setBackground(new Color(2, 1, 1));
        add(jbVoltar);
        jbVoltar.addActionListener(this:: voltar);



    }

    public TelaModuloEscolhido()  {
        new TelaModuloEscolhido(nomeModulo);

    }

    public static TelaModuloEscolhido telaModuloEscolhido(){
        try {
            if (instancia == null || nomeModulo.equals("")){
                instancia = new TelaModuloEscolhido();
                return new TelaModuloEscolhido();
            }else {
                return null;
            }



        }catch (Exception a){
            JOptionPane.showInputDialog("está janela já está aberta");
        }

        JOptionPane.showInputDialog("está janela já está aberta");

        return null;

    }






    // Método para verificar se a janela está aberta





    private void voltar(ActionEvent actionEvent) {
        this.toBack();
        TelaModulosAluno.getInstance();

    }

    @Override
    public void STATICgetInstance() {
        getInstance();
    }
    public static TelaModuloEscolhido getInstance() {

            if (instancia == null) {
                instancia = new TelaModuloEscolhido();
                // Define o estado da janela como aberta
                TelaAberta = true;
            }
            return instancia;
        }


    @Override
    public void STATICfecharJanela() {
        fecharJanela();
        // Fecha a janela
        dispose();

    }
    public static void fecharJanela() {

        // Define o estado da janela como fechada
        TelaAberta = false;
    }

    @Override
    public boolean STATICisJanelaAberta() {
        return isTelaAberta();
    }
    public static boolean isTelaAberta() {
        return TelaAberta;
    }

    @Override
    public void STATICverificaJanelaAberta() {
        verificaJanelaAberta();
    }
    public void verificaJanelaAberta() {
        // Verifica se a janela já está aberta antes de criar uma nova instância
        if (!instancia.isTelaAberta()) {
            // Obtenha a instância da janela
            TelaModuloEscolhido janela = instancia.getInstance();
        } else {
            System.out.println("A janela já está aberta.");
        }
    }
}
