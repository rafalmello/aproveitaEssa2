package Exceptions;

public class ModuloException {

}
