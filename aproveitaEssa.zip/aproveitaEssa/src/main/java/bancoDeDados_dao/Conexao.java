package bancoDeDados_dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class Conexao {

    //EngenhariaReversaTailiniEhRafael

    //conexão foi feita com sucesso. todo o sistema está conectado graças a está classe

    public static Connection conection = getConnection();

    public static Connection getConnection() {
        String url = "jdbc:postgresql://localhost:5432/AproveitaEssa";
        String user = "postgres";
        String password = "julioelira";

        try {
            System.out.println("conexão realizada com sucesso");
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Erro ao conectar ao banco de dados");
        }
    }

    public static Connection getConection() {
        return conection;
    }

    public static void setConection(Connection conection) {
        Conexao.conection = conection;
    }

    public static void main(String[] args) {
       getConnection();
    }


}
