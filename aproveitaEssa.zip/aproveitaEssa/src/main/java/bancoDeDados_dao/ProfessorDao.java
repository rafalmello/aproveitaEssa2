package bancoDeDados_dao;

import Models.Professor;

import java.util.ArrayList;
import java.util.List;

public class ProfessorDao {
    static List<Professor>todosProfessores = new ArrayList<Professor>();

    public ProfessorDao() {
    }

    public static List<Professor> getTodosProfessores() {
        return todosProfessores;
    }

    public static void setTodosProfessores(List<Professor> todosProfessores) {
        ProfessorDao.todosProfessores = todosProfessores;
    }
}
