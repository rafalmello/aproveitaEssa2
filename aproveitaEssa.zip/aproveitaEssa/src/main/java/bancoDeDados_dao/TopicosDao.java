package bancoDeDados_dao;

import Models.Topico;

import java.util.List;

public class TopicosDao {
    private static List<Topico> topicos;

    public List<Topico> getTopicos() {
        return topicos;
    }
}
