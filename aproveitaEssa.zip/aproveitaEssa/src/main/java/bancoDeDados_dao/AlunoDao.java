package bancoDeDados_dao;

import Models.Aluno;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AlunoDao {



    /*public static void salvarAlunoBD(Aluno aluno ){

        Connection connection = Conexao.getConnection();

        String sql = "INSERT INTO ALUNO (Nome, CPF, Idade, NomeCurso)  VALUES(?,?,?,?)";
        PreparedStatement pstmt;
        try{
            pstmt = connection.prepareStatement(sql);

            pstmt.setString(1,aluno.getIdUsuario());
            pstmt.setInt(2,aluno.getCPF());// estudar depois
            pstmt.setInt(3,aluno.getIdade());
            pstmt.setString(4,aluno.getNomeCurso());
            pstmt.setString(5,a);
            pstmt.setString(6,);
            pstmt.setString(7);
            pstmt.setString(8);
            pstmt.setString(9);




            pstmt.execute();

            System.out.println("Aluno gravado com Sucesso!");

            final ResultSet resultado = pstmt.getGeneratedKeys();

            if (resultado.next()){
                int id = resultado.getInt(1);
                aluno.setCPF(id);
            }
            return true;
        } catch (SQLException e) {
            System.out.println(" Não foi possível gravar o aluno " + e.getMessage());
            return false;
        }


    }*/

    static List<Aluno>todosAlunos = new ArrayList<Aluno>();

    public AlunoDao() {
    }

    public static List<Aluno> getTodosAlunos() {
        return todosAlunos;
    }

    public static void setTodosAlunos(List<Aluno> todosAlunos) {
        AlunoDao.todosAlunos = todosAlunos;
    }
}
