package Models;

import java.util.List;

public class Modulo {

    private int idModulo;
    private double cargaHoraria;

    private String nomeModulo;
    private Professor professorResponsavel; //todo Modulo deve ter um professor Responsavel para tirar duvidar e dar aulas.
    private List <Topico> topicos;

    private Disciplina disciplinaCorrespondente;

    public Modulo(double cargaHoraria, String nomeModulo, Aluno aluno, Professor professorResponsavel,
                  List<Topico> topicos, Disciplina disciplinaCorrespondente) {

        this.cargaHoraria = cargaHoraria;
        this.nomeModulo = nomeModulo;
        this.professorResponsavel = professorResponsavel;
        this.topicos = topicos;
        this.disciplinaCorrespondente = disciplinaCorrespondente;
    }

    public Disciplina getDisciplinaCorrespondente() {
        return disciplinaCorrespondente;
    }

    public void setDisciplinaCorrespondente(Disciplina disciplinaCorrespondente) {
        this.disciplinaCorrespondente = disciplinaCorrespondente;
    }

    public double getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(double cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getNomeModulo() {
        return nomeModulo;
    }

    public void setNomeModulo(String nomeModulo) {
        this.nomeModulo = nomeModulo;
    }



    public Professor getProfessor() {
        return professorResponsavel;
    }

    public void setProfessor(Professor professor) {
        this.professorResponsavel = professor;
    }

    public List<Topico> getTopicos() {
        return topicos;
    }

    public void setTopicos(List<Topico> topicos) {
        this.topicos = topicos;
    }
}
