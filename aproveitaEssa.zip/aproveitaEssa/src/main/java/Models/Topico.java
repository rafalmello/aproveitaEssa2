package Models;

import javax.swing.text.Document;

public class Topico {
    private double cargaHoraria;
    private String nomeTopico;
    private enum TipoDeTopico{links, exercicio, aula, texto};

    private Document[] topicos;// = { "links","exercicio","aula","texto","prova"} ;

    private int idTopico;

    public Topico(double cargaHoraria, String nomeTopico) {
        this.cargaHoraria = cargaHoraria;
        this.nomeTopico = nomeTopico;
    }

    public double getCargaHoraria() {
        return cargaHoraria;
    }

    public void setCargaHoraria(double cargaHoraria) {
        this.cargaHoraria = cargaHoraria;
    }

    public String getNomeTopico() {
        return nomeTopico;
    }

    public void setNomeTopico(String nomeTopico) {
        this.nomeTopico = nomeTopico;
    }
}
