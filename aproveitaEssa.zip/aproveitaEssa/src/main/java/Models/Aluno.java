package Models;

import java.util.ArrayList;
import java.util.List;

public class Aluno extends Usuario {
    private String curso;
    private List <Disciplina> disciplinas;
    private List <Modulo> modulos = new ArrayList<>();
    private String instituicao;
    private double idAluno;

    public Aluno(String nome, String email, String senha, double telefone, String cpf, double idUsuario, String curso, List<Disciplina> disciplinas,List<Modulo> modulos) {
        super(nome, email, senha, telefone, cpf,idUsuario);
        this.curso = curso;
        this.modulos = new ArrayList<>();
        this.disciplinas = new ArrayList<>();
    }





    public List<Disciplina> getDisciplinas() {
        return disciplinas;
    }

    public void setDisciplinas(List<Disciplina> disciplinas) {
        this.disciplinas = disciplinas;
    }

    public List<Modulo> getModulos() {

        return modulos;
    }

    public void setModulos(List<Modulo> modulos) {
        this.modulos = modulos;
    }


}
