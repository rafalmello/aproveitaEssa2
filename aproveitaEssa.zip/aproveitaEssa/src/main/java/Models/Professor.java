package Models;

import java.util.List;

public class Professor extends Usuario{

    private int idProfessor;
    private double salario;
    private List <Aluno> alunos;
    private List <Modulo> modulos;

    private List<Topico>topicos;

    private static int idProfessor2 = 0;

    public Professor(String nome, String email, String senha, double telefone, int idProfessor, double salario,
                     List<Aluno> alunos, List<Modulo> modulos, String cpf, double idUsuario) {
        super(nome, email, senha,  telefone, cpf, idUsuario);
        this.idProfessor = idProfessor;
        this.salario = salario;
        this.alunos = alunos;
        this.modulos = modulos;
    }

    public int getIdProfessor() {
        return idProfessor;
    }

    public List<Topico> getTopicos() {
        return topicos;
    }

    public static int getIdProfessor2() {
        return idProfessor2;
    }

    private int idProfessor() {
        this.idProfessor2++;
        this.idProfessor = idProfessor2;
        return idProfessor;
    }


    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }



    public List<Aluno> getAlunos() {
        return alunos;
    }

    public void setAlunos(List<Aluno> alunos) {
        this.alunos = alunos;
    }

    public List<Modulo> getModulos() {
        return modulos;
    }

    public void setModulos(List<Modulo> modulos) {
        this.modulos = modulos;
    }
}
