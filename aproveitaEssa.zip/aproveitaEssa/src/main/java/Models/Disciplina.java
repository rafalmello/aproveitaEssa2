package Models;

import java.util.List;

public class Disciplina {



    private int IdDisciplina;
    private String nomeDisciplina;

    private String ementa;

    private String instituicao;//pode ser retirada

    private List<String> conteudos;

    public Disciplina(String nomeDisciplina,  String instituicao, List<String> conteudos, int idDisciplina) {
        this.nomeDisciplina = nomeDisciplina;
        this.instituicao = instituicao;
        this.conteudos = conteudos;
        this.IdDisciplina = idDisciplina;
    }

    public String getNomeDisciplina() {
        return nomeDisciplina;
    }

    public void setNomeDisciplina(String nomeDisciplina) {
        this.nomeDisciplina = nomeDisciplina;
    }

    public String getInstituicao() {
        return instituicao;
    }

    public void setInstituicao(String instituicao) {
        this.instituicao = instituicao;
    }

    public List<String> getConteudos() {
        return conteudos;
    }

    public void setConteudos(List<String> conteudos) {
        this.conteudos = conteudos;
    }
}
