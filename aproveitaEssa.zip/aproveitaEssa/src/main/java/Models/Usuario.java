package Models;

public abstract class Usuario {
    protected String nome;
    protected String cpf;
    protected String email;
    protected String senha;
    protected double telefone;

    protected  double idUsuario;
    static int idUsuario2 = 0;


    public Usuario(String nome, String email, String senha, double telefone,String cpf,double idUsuario) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.cpf = cpf;
        this.idUsuario = idUsuario();
    }



    private static double idUsuario() {
        idUsuario2++;
        return idUsuario2;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public double getTelefone() {
        return telefone;
    }

    public void setTelefone(double telefone) {
        this.telefone = telefone;
    }

    public double getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(double idUsuario) {
        this.idUsuario = idUsuario;
    }
}
